# src/routes/analysis.py

import json
import re
from fastapi import APIRouter, Depends
from pydantic import BaseModel

# --- 필요한 모듈 import ---
from ..utils.auth import get_current_user
from ..models.models import User
from ..services.langchain_agent.tools import llm, tool_map
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser

# --- API 라우터 설정 ---
router = APIRouter(prefix="/api/analysis", tags=["Analysis Q&A"])
class QuestionRequest(BaseModel):
    question: str

# --- '교통정리' 담당 라우터 체인 정의 ---
router_prompt_template = """
Your task is to classify the user's question into one of the following categories.
Respond with ONLY the lowercase category name. Do not add any other text.

Categories:
- sql: For questions about user accounts, sessions, or saved incident reports.
- attack: For searching specific attack records.
- traffic: For searching network traffic or packet data.
- log: For searching general system logs or events.
- security_knowledge: For questions asking for explanations about security concepts (e.g., 'What is DDoS?').

---
Here are some examples:
Question: 내 최근 로그인 기록 보여줘
Choice: sql
Question: DDoS 공격 대응법 알려줘
Choice: security_knowledge
Question: 어제 발생한 트래픽 데이터 요약해줘
Choice: traffic
---
Now, classify the following question.
Question: {question}
Choice:"""
router_prompt = PromptTemplate.from_template(router_prompt_template)
router_chain = router_prompt | llm | StrOutputParser()


# --- 메인 API 엔드포인트 ---
@router.post("/ask")
async def ask_question(
    request: QuestionRequest,
    current_user: User = Depends(get_current_user)
):
    """사용자의 질문을 라우팅하고, 전문가 도구를 실행한 뒤, 최종 결과를 요약하여 답변합니다."""
    question = request.question
    user_id = current_user.user_id
    print(f"--- [요청 시작] User ID: {user_id}, Question: {question} ---")

    # 1. 라우터 체인을 실행하여 전문가 이름(예: 'traffic')을 얻습니다.
    chosen_tool_name = await router_chain.ainvoke({"question": question})
    chosen_tool_name = chosen_tool_name.strip().lower()
    print(f"--- [라우터 선택]: {chosen_tool_name} ---")

    # 2. 선택된 전문가 도구를 가져옵니다.
    if chosen_tool_name not in tool_map:
        return {"answer": "죄송합니다, 질문의 의도를 파악하지 못했습니다."}
    selected_tool = tool_map[chosen_tool_name]

    # 3. 선택된 전문가에게 컨텍스트와 함께 질문을 전달하고 실행합니다.
    action_input = f"[User ID: {user_id}] {question}" if chosen_tool_name in ["attack", "traffic", "log"] else question
    tool_result = await selected_tool.ainvoke(action_input)
    print(f"--- [도구 실행 결과]: {tool_result} ---")
    
    # 4. 최종 답변 생성을 위한 데이터 가공 및 요약
    final_answer = ""
    # '보안 전문가'는 이미 완성된 답변을 생성하므로, 그 결과를 바로 사용합니다.
    if chosen_tool_name == "security_knowledge":
        if isinstance(tool_result, dict):
            final_answer = tool_result.get('result', "답변을 생성하지 못했습니다.")
        else:
            final_answer = str(tool_result)
    else:
        # 나머지 도구들(Elasticsearch, SQL)은 결과를 가공하고 최종 요약 단계를 거칩니다.
        if "데이터를 찾을 수 없습니다" in str(tool_result):
            return {"answer": "요청하신 조건에 맞는 데이터를 찾을 수 없습니다."}

        # ▼▼▼ [핵심] 데이터 종류에 맞는 '지능형 데이터 가공' 로직 ▼▼▼
        processed_text = f"도구 '{chosen_tool_name}'가 찾은 데이터는 다음과 같습니다:\n\n"
        try:
            retrieved_data = json.loads(tool_result)
            if not retrieved_data:
                processed_text = "관련 데이터를 찾지 못했습니다."
            
            elif isinstance(retrieved_data, list):
                # 각 도구의 결과에 맞게 중요한 정보만 추출하여 텍스트로 만듭니다.
                if chosen_tool_name == 'traffic':
                    for i, item in enumerate(retrieved_data[:5], 1): # 최대 5개만 처리
                        processed_text += f"{i}. 시간: {item.get('@timestamp', 'N/A')}, 출발지IP: {item.get('Src_IP', 'N/A')}, 목적지포트: {item.get('Dst_Port', 'N/A')}\n"
                elif chosen_tool_name == 'log':
                    for i, item in enumerate(retrieved_data[:5], 1):
                        processed_text += f"{i}. 시간: {item.get('@timestamp', 'N/A')}, 로그레벨: {item.get('log.level', 'N/A')}, 메시지: {item.get('message', 'N/A')}\n"
                elif chosen_tool_name == 'attack':
                    for i, item in enumerate(retrieved_data[:5], 1):
                        processed_text += f"{i}. 시간: {item.get('timestamp', 'N/A')}, 공격유형: {item.get('attack_type', 'N/A')}, 공격IP: {item.get('source_ip', 'N/A')}\n"
            
            elif isinstance(retrieved_data, dict): # 통계(aggs) 결과일 경우
                processed_text += json.dumps(retrieved_data, indent=2, ensure_ascii=False)
        
        except (json.JSONDecodeError, TypeError):
            processed_text = tool_result # JSON이 아니면 그냥 원본 텍스트 사용

        print(f"--- [디버그] LLM 요약을 위한 최종 입력 데이터 ---\n{processed_text}")
        
        # 5. 가공된 데이터를 바탕으로 최종 답변 생성
        final_summary_template = """
        Based on the user's original question and the following retrieved data, 
        provide a final, concise, and easy-to-understand summary in Korean.
        If the data says no data was found, just say "요청하신 데이터를 찾을 수 없습니다." in Korean.
        Do not add any other English text.

        Original Question: {question}
        Retrieved Data:
        {result}
        Final Answer (Korean ONLY):
        """
        final_summary_prompt = PromptTemplate.from_template(final_summary_template)
        final_chain = final_summary_prompt | llm | StrOutputParser()
        final_answer = await final_chain.ainvoke({"question": question, "result": processed_text})

    return {"answer": final_answer}