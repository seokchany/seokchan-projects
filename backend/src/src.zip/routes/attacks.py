# src/routes/attacks.py

from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from pydantic import BaseModel
from datetime import datetime

from ..services import email_service, sms_service
from ..core.database import get_db # 비동기 get_db 의존성
from ..models import models # models.py 파일 전체를 import

router = APIRouter(prefix="/api/internal", tags=["Internal Notifier"])

# --- [수정] ---
# DB 스키마에 맞춰 IncidentReport 생성을 위해 log_id를 필수로 받도록 수정하고,
# AttackData 생성을 위해 traffic_id를 옵션으로 받도록 추가합니다.
class AlertPayload(BaseModel):
    user_id: str
    attack_type: str
    message: str
    log_id: int  # IncidentReport 생성을 위해 필수
    traffic_id: int | None = None # AttackData에 기록할 수 있는 옵션 필드
    source_ip: str | None = None

@router.post("/alert", status_code=status.HTTP_202_ACCEPTED)
async def trigger_user_alert(
    payload: AlertPayload,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db) # 비동기 세션으로 변경
):
    """
    내부 모니터링 시스템으로부터 특정 사용자에게 보낼 알림 요청을 받습니다.
    (PostgreSQL DB 스키마에 맞게 수정됨)
    """
    # --- [수정] ---
    # 사용자 조회 로직을 비동기 방식으로 변경합니다.
    stmt = select(models.User).where(models.User.user_id == payload.user_id)
    result = await db.execute(stmt)
    db_user = result.scalars().first()

    if not db_user:
        print(f"알림 대상 사용자를 찾지 못함: {payload.user_id}")
        # 사용자가 없더라도 요청은 정상 처리된 것으로 간주 (202 ACCEPTED)
        return {"message": "User not found, but request accepted."}

    # --- [수정] ---
    # AttackData 모델의 필드에 맞게 데이터를 생성합니다.
    new_attack = models.AttackData(
        traffic_id=payload.traffic_id, # payload에서 받은 traffic_id 사용
        log_id=payload.log_id,         # payload에서 받은 log_id 사용
        detected_at=datetime.utcnow(),
        attack_type=payload.attack_type,
        severity="High",
        confidence=90.0,
        description=payload.message,
        response_type="Automated",
        responded_at=datetime.utcnow()
    )
    db.add(new_attack)
    # commit을 해야 new_attack.attack_id가 생성됩니다.
    await db.commit()
    await db.refresh(new_attack)

    # --- [수정] ---
    # IncidentReport 모델의 필드에 맞게 데이터를 생성합니다.
    # log_id는 필수 항목이므로 payload에서 받은 값을 사용합니다.
    new_report = models.IncidentReport(
        user_id=db_user.user_id,
        attack_id=new_attack.attack_id,
        log_id=payload.log_id, # payload에서 받은 log_id 사용
        summary=f"Incident report for {payload.attack_type}",
        recommendations="Initial recommendation: check logs and system status."
    )
    db.add(new_report)
    await db.commit()
    
    # 이메일 및 SMS 발송 로직 (백그라운드 처리)
    subject = f"[보안 경고] {payload.attack_type} 공격 탐지"
    body = f"안녕하세요, {db_user.name}님. 계정에서 보안 공격이 탐지되었습니다. 상세 내용은 대시보드를 확인해 주세요."
    sms_message = f"[{payload.attack_type}] 보안 경고 탐지. 대시보드 확인."

    background_tasks.add_task(email_service.send_alert_email, db_user.email, subject, body)
    if db_user.phone:
        background_tasks.add_task(sms_service.send_alert_sms, db_user.phone, sms_message)

    return {"message": "Alert tasks have been successfully scheduled."}
