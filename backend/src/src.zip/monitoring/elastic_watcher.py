# src/monitoring/elastic_watcher.py

import asyncio  # [변경] time 대신 asyncio 임포트
from datetime import datetime, timezone
from elasticsearch import AsyncElasticsearch  # [변경] 비동기 클라이언트 임포트
import httpx  # [변경] requests 대신 httpx 임포트

# --- [추가] 설정 객체 임포트 ---
from ..core.config import settings

# --- 1. 설정 및 초기화 ---
ELASTIC_HOST = f"{settings.elasticsearch_host}:{settings.elasticsearch_port}"
ALERT_API_URL = f"{settings.internal_api_base_url}/api/internal/alert"
POLLING_INTERVAL = settings.monitoring_polling_interval

try:
    # [변경] AsyncElasticsearch 클라이언트로 초기화
    es_client = AsyncElasticsearch(ELASTIC_HOST, request_timeout=settings.elasticsearch_request_timeout)
    print("✅ Elasticsearch에 성공적으로 연결되었습니다.")
except Exception as e:
    print(f"❌ Elasticsearch 연결 실패: {e}")

# --- 2. 핵심 기능 함수 (비동기로 변경) ---

# [변경] async def로 함수 정의
async def fetch_new_attacks():
    """'alert_sent' 필드가 없는 새로운 공격 문서를 가져옵니다."""
    query = {
        "query": {
            "bool": {
                "must_not": [
                    {"exists": {"field": "alert_sent"}}
                ]
            }
        }
    }
    try:
        # [변경] await로 비동기 호출
        response = await es_client.search(index="attack_detections", body=query)
        return response['hits']['hits']
    except Exception as e:
        print(f"❌ Elasticsearch 검색 중 오류 발생: {e}")
        return []

# [변경] async def로 함수 정의
async def mark_alert_as_sent(doc_id):
    """공격 문서에 'alert_sent: true' 필드를 추가하여 처리되었음을 표시합니다."""
    try:
        # [변경] await로 비동기 호출
        await es_client.update(
            index="attack_detections",
            id=doc_id,
            body={"doc": {"alert_sent": True}}
        )
        print(f"  - 📝 처리 완료 표시: Doc ID={doc_id}")
    except Exception as e:
        print(f"  - ❌ 처리 표시 중 오류 발생: {e}")

# [변경] async def로 함수 정의 및 httpx 사용
async def call_alert_api(payload: dict):
    """FastAPI 서버의 알림 API를 호출합니다."""
    async with httpx.AsyncClient() as client:  # [변경] 비동기 HTTP 클라이언트 사용
        try:
            # [변경] await로 비동기 호출
            response = await client.post(ALERT_API_URL, json=payload, timeout=10)
            response.raise_for_status()
            print(f"  - ✅ API 호출 성공: user_id={payload.get('user_id')}")
            return True
        except httpx.RequestError as e:  # [변경] httpx 예외 처리
            print(f"  - ❌ API 호출 실패: {e}")
            return False

# --- 3. 메인 실행 루프 (비동기로 변경) ---
# [변경] 메인 로직을 async main 함수로 정의
async def main():
    print("🚀 실시간 개인화 공격 알림 시스템 (비동기 모드)을 시작합니다...")
    while True:
        # [변경] await로 비동기 함수 호출
        new_attacks = await fetch_new_attacks()
        
        if new_attacks:
            print(f"🚨 [{datetime.now(timezone.utc).isoformat()}] {len(new_attacks)}개의 새로운 공격 탐지!")
            for attack in new_attacks:
                doc_id = attack['_id']
                source = attack['_source']
                
                user_id = source.get("user", {}).get("id") or source.get("agent_id")
                if not user_id:
                    print(f"  - ⚠️ 경고: user_id 또는 agent_id가 없어 건너킵니다. Doc ID: {doc_id}")
                    await mark_alert_as_sent(doc_id) # [변경] await 추가
                    continue

                alert_payload = {
                    "user_id": user_id,
                    "attack_type": source.get("attack_type") or source.get("rule", {}).get("name", "Unknown Attack"),
                    "message": f"Attack from {source.get('source_ip', 'N/A')}",
                    "source_ip": source.get("source_ip") or source.get("source", {}).get("ip")
                }
                
                # [변경] await로 비동기 함수 호출
                if await call_alert_api(alert_payload):
                    await mark_alert_as_sent(doc_id) # [변경] await 추가
        
        await asyncio.sleep(POLLING_INTERVAL) # [변경] time.sleep 대신 asyncio.sleep 사용

# [변경] asyncio.run으로 비동기 메인 함수 실행
if __name__ == "__main__":
    asyncio.run(main())