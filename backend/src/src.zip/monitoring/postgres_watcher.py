# src/monitoring/postgres_watcher.py

import os
import sys
import requests
import time
from datetime import datetime, timezone, timedelta
from collections import defaultdict

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(project_root)

from src.core.database import SessionLocal
from src.models.models import AttackLog, AttackTraffic, AlertHistory
from src.core.config import settings

# --- 설정 ---
ALERT_API_URL = "http://127.0.0.1:8000/api/internal/alert"
POLLING_INTERVAL = 10
ALERT_COOLDOWN_MINUTES = 10

# --- 2. 핵심 기능 함수 ---
# --- 함수 정의 ---
def fetch_unprocessed_attacks(db, model):
    return db.query(model).filter(model.notification == False).all()

def mark_attacks_as_sent(db, model, attack_ids):
    if not attack_ids: return
    try:
        db.query(model).filter(model.id.in_(attack_ids)).update({"notification": True}, synchronize_session=False)
        db.commit()
    except Exception as e: db.rollback(); print(f"DB 업데이트 오류: {e}")

def call_alert_api(payload: dict):
    """FastAPI 서버의 알림 API를 호출합니다."""
    try:
        response = requests.post(ALERT_API_URL, json=payload, timeout=10)
        response.raise_for_status()
        print(f"  - ✅ API 호출 성공: user_id={payload.get('user_id')}, type={payload.get('attack_type')}")
        return True
    except requests.RequestException as e:
        print(f"  - ❌ API 호출 실패: {e}")
        return False

def process_attacks(db, attacks, model, attack_id_field):
    if not attacks: return
    print(f"🚨 {len(attacks)}개의 새로운 '{model.__tablename__}' 공격 탐지!")
    
    grouped_attacks = defaultdict(list)
    for attack in attacks:
        if attack.user_id:
            grouped_attacks[(attack.user_id, attack.attack_type)].append(attack)

    for (user_id, attack_type), attack_list in grouped_attacks.items():
        history = db.query(AlertHistory).filter_by(user_id=user_id, attack_type=attack_type).first()
        now = datetime.now(timezone.utc)
        cooldown_time = now - timedelta(minutes=ALERT_COOLDOWN_MINUTES)
        
        if not history or history.last_sent_at < cooldown_time:
            payload = {
                "user_id": user_id,
                "attack_type": attack_type,
                "message": f"{len(attack_list)}건의 '{attack_type}' 공격 탐지.",
                "source_ip": getattr(attack_list[0], 'source_address', None) or getattr(attack_list[0], 'Src_IP', None)
            }
            if call_alert_api(payload):
                if history: history.last_sent_at = now
                else: db.add(AlertHistory(user_id=user_id, attack_type=attack_type, last_sent_at=now))
                db.commit()
        
        processed_ids = [getattr(a, attack_id_field) for a in attack_list]
        mark_attacks_as_sent(db, model, processed_ids)

# --- 메인 루프 ---
if __name__ == "__main__":
    print("🚀 PostgreSQL 기반 지능형 알림 시스템을 시작합니다...")
    while True:
        db_session = SessionLocal()
        try:
            process_attacks(db_session, fetch_unprocessed_attacks(db_session, AttackLog), AttackLog, "log_id")
            process_attacks(db_session, fetch_unprocessed_attacks(db_session, AttackTraffic), AttackTraffic, "traffic_id")
        finally:
            db_session.close()
        time.sleep(POLLING_INTERVAL)