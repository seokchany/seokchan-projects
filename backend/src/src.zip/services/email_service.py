# src/services/email_service.py
import aiosmtplib  # [변경] smtplib 대신 aiosmtplib 임포트
from email.message import EmailMessage
from ..core.config import settings

# [변경] async def로 함수 시그니처 변경
async def send_alert_email(recipient_email: str, subject: str, body: str):
    """SMTP를 사용하여 보안 알림 이메일을 비동기적으로 발송합니다."""
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = settings.mail_from
    msg['To'] = recipient_email
    msg.set_content(body)

    try:
        # [변경] aiosmtplib.SMTP 컨텍스트 매니저 사용
        smtp = aiosmtplib.SMTP(hostname=settings.mail_server, port=settings.mail_port)
        async with smtp:
            # [변경] 모든 SMTP 명령어에 await 추가
            await smtp.starttls()
            await smtp.login(settings.mail_username, settings.mail_password)
            await smtp.send_message(msg)
            print(f"SMTP Email sent successfully to {recipient_email}")
            return True
    except Exception as e:
        print(f"Failed to send email via SMTP: {e}")
        return False