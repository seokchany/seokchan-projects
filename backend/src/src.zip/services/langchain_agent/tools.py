# src/services/langchain_agent/tools.py

# ===============================================================
# [중요] NumPy 2.0 호환성 패치
# ---------------------------------------------------------------
# chromadb 라이브러리가 최신 NumPy 버전과 충돌하는 문제를 해결하기 위한 코드입니다.
# 다른 모든 모듈이 임포트되기 전에 가장 먼저 실행되어야 합니다.
# =================================----------------==============
import numpy as np
try:
    # NumPy 2.0 이상 버전에서는 np.float_가 없어서 에러가 발생합니다.
    _ = np.float_
except AttributeError:
    # 에러 발생 시, np.float_를 np.float64로 대체하여 호환성을 맞춥니다.
    print("--- [호환성 패치 적용] NumPy 2.0+ 환경에서 np.float_를 np.float64로 대체합니다. ---")
    np.float_ = np.float64
# --- 패치 코드 끝 ---

import json
import traceback
import re
from sqlalchemy import create_engine, text
from sqlalchemy.ext.asyncio import AsyncSession
from langchain.tools import tool
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_ollama.chat_models import ChatOllama
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from elasticsearch import AsyncElasticsearch

# RAG (검색 증강 생성) 도구를 위한 import
from langchain.chains import RetrievalQA
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

# 프로젝트 내부 모듈 import
from ...core.database import AsyncSessionLocal # 비동기 DB 세션 생성기
from ...core.config import settings

# --- 1. 공통 LLM 및 클라이언트 초기화 ---

# 프로젝트 전체에서 사용할 단일 LLM 객체 (로컬 Llama 3)
llm = ChatOllama(model="llama3:8b")

# Elasticsearch와의 비동기 통신을 위한 클라이언트 객체
es_client = AsyncElasticsearch(
    f"{settings.elasticsearch_host}:{settings.elasticsearch_port}",
    request_timeout=settings.elasticsearch_request_timeout
)

# --- 2. JSON 추출 헬퍼 함수 ---

# 이 함수는 순수 텍스트 처리(CPU 작업)이며, 네트워크나 디스크 I/O를 기다리지 않으므로
# 일반 동기 함수(def)로 정의하는 것이 올바르고 효율적입니다.
def extract_json_from_string(text: str) -> str:
    """LLM이 반환한 텍스트에서 JSON 코드 블록만 안정적으로 추출합니다."""
    match = re.search(r"```(json)?\n(.*?)```", text, re.S)
    if match: return match.group(2).strip()
    try:
        start = text.index("{"); end = text.rindex("}") + 1
        return text[start:end]
    except ValueError: return ""

# --- 3. 전문가 도구(Tool) 정의 ---

# --- [공통 함수: Elasticsearch 쿼리 생성 및 실행 (비동기)] ---
# Elasticsearch와 네트워크 통신(I/O)을 하므로 비동기 함수(async def)로 정의합니다.
async def create_es_query_and_search(question: str, user_id: str, index_name: str, schema: str):
    """Elasticsearch 쿼리 템플릿을 생성하고, user_id를 강제로 삽입한 후 비동기로 실행하는 공통 함수"""
    
    query_gen_template = """
You are an expert at creating simple Elasticsearch search queries.
Your task is to generate a JSON query to find relevant documents.
**Index Schema (Use ONLY these fields):** {schema}
**CRUCIAL INSTRUCTIONS:**
1. You MUST include a filter for the user's ID. Use a `match` query on the `user_id` field with "USER_ID_TO_REPLACE" as the temporary value.
2. If the user asks for "oldest" or "first" data, sort by the timestamp field in "asc" order. Otherwise, sort in "desc" order.
3. Set the "size" to 10. DO NOT use "aggs".
4. Only output the raw, valid JSON in a ```json ... ``` code block.
User Question: {question}
DSL Query:
"""
    query_gen_prompt = PromptTemplate.from_template(query_gen_template)
    query_chain = query_gen_prompt | llm | StrOutputParser()
    
    llm_output_str = await query_chain.ainvoke({"question": question, "schema": schema})
    dsl_template_str = extract_json_from_string(llm_output_str)

    if not dsl_template_str: return "LLM이 유효한 DSL 쿼리 템플릿을 생성하지 못했습니다."

    try:
        final_dsl_str = dsl_template_str.replace("USER_ID_TO_REPLACE", user_id)
        query_dict = json.loads(final_dsl_str)
    except Exception as e: return f"생성된 쿼리를 파싱하는 데 실패했습니다. 오류: {e}"

    try:
        es_result = await es_client.search(index=index_name, body=query_dict)
        hits = es_result.get('hits', {}).get('hits', [])
        if not hits: return "요청하신 조건에 맞는 데이터를 찾을 수 없습니다."
    except Exception as e: return f"쿼리 실행 실패: {e}."

    result_to_return = [hit.get('_source', {}) for hit in hits]
    return json.dumps(result_to_return, ensure_ascii=False)


# --- [개별 전문가 도구 정의] ---
# 각 도구는 I/O 작업(DB 또는 Elasticsearch 조회)을 포함하므로, 모두 비동기 함수(async def)여야 합니다.

@tool
async def attack_search_tool(question_with_context: str) -> str:
    """사용자의 '공격(attack)' 기록을 PostgreSQL의 Attack_log와 Attack_traffic 테이블에서 직접 검색합니다."""
    db_session: AsyncSession = AsyncSessionLocal()
    try:
        match = re.search(r"\[User ID: ([\w\-.]+)\]", question_with_context)
        if not match: return "오류: 입력에서 User ID를 찾을 수 없습니다."
        user_id = match.group(1)
        
        log_query = text("SELECT detected_at, attack_type, source_address FROM \"Attack_log\" WHERE user_id = :user_id ORDER BY detected_at DESC LIMIT 5")
        log_result = await db_session.execute(log_query, {"user_id": user_id})
        log_list = log_result.mappings().all()

        traffic_query = text("SELECT \"@timestamp\" as detected_at, 'Traffic Anomaly' as attack_type, \"Src_IP\" as source_address FROM \"Attack_traffic\" WHERE user_id = :user_id ORDER BY \"@timestamp\" DESC LIMIT 5")
        traffic_result = await db_session.execute(traffic_query, {"user_id": user_id})
        traffic_list = traffic_result.mappings().all()

        if not log_list and not traffic_list:
            return "관련 공격 데이터를 찾을 수 없습니다."

        final_report = "조회된 공격 데이터는 다음과 같습니다.\n"
        if log_list:
            final_report += "\n[로그 기반 공격]\n"
            for item in log_list: final_report += f"- 시간: {item['detected_at']}, 유형: {item['attack_type']}, 출처: {item['source_address']}\n"
        if traffic_list:
            final_report += "\n[트래픽 기반 공격]\n"
            for item in traffic_list: final_report += f"- 시간: {item['detected_at']}, 유형: {item['attack_type']}, 출처: {item['source_address']}\n"
        
        return final_report
    except Exception as e:
        return f"공격 데이터 조회 중 오류가 발생했습니다: {e}"
    finally:
        await db_session.close()

@tool
async def traffic_search_tool(question_with_context: str) -> str:
    """사용자의 네트워크 '트래픽(traffic)' 또는 '패킷(packet)' 데이터를 Elasticsearch에서 검색합니다."""
    match = re.search(r"\[User ID: ([\w\-.]+)\]", question_with_context)
    if not match: return "Error: User ID context is missing from the input."
    user_id = match.group(1)
    question = question_with_context.replace(match.group(0), "").strip()
    schema = "'packetbeat-raw' fields: [\"@timestamp\", \"user_id\", \"Src_IP\", \"Dst_Port\"]"
    return await create_es_query_and_search(question, user_id, "packetbeat-raw", schema)

@tool
async def log_search_tool(question_with_context: str) -> str:
    """사용자의 일반 '로그(log)' 또는 '이벤트(event)' 기록을 Elasticsearch에서 검색합니다."""
    match = re.search(r"\[User ID: ([\w\-.]+)\]", question_with_context)
    if not match: return "Error: User ID context is missing from the input."
    user_id = match.group(1)
    question = question_with_context.replace(match.group(0), "").strip()
    schema = "'winlogbeat-raw' fields: [\"@timestamp\", \"user_id\", \"host.name\", \"message\"]"
    return await create_es_query_and_search(question, user_id, "winlogbeat-raw", schema)


# --- [SQL 전문가 도구] ---
@tool
async def sql_expert_tool(question: str) -> str:
    """'내 계정 정보 보여줘' 와 같이 사용자 계정, 세션 등 PostgreSQL DB의 정적 관리 데이터를 조회할 때 사용합니다."""
    # SQL Agent는 비동기 호출(ainvoke)을 지원합니다.
    sync_engine = create_engine(settings.database_url.replace("+asyncpg", ""))
    db = SQLDatabase(engine=sync_engine)
    sql_agent_executor = create_sql_agent(llm=llm, db=db, agent_type="openai-tools", verbose=True, handle_parsing_errors=True)
    return await sql_agent_executor.ainvoke({"input": question})

# --- [보안 지식 전문가 (RAG)] ---
@tool
async def security_knowledge_tool(question: str) -> str:
    """'DDoS란?', '피싱 대응법' 등 보안 개념이나 지식에 대한 '설명'이 필요할 때 사용합니다."""
    # RAG 체인 생성 로직을 함수 내부로 이동하여 매번 최신 상태로 생성하도록 개선
    embeddings = HuggingFaceEmbeddings(model_name="BAAI/bge-m3")
    vectordb = Chroma(persist_directory="./chroma_db", embedding_function=embeddings)
    prompt_template = "Context: {context}\n\nQuestion: {question}\n\nAnswer in Korean:"
    PROMPT = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm, chain_type="stuff", retriever=vectordb.as_retriever(),
        return_source_documents=True, chain_type_kwargs={"prompt": PROMPT}
    )
    # RAG 체인도 비동기(ainvoke)로 호출합니다.
    result = await qa_chain.ainvoke(question)
    answer = result.get('result', "답변 생성 실패")
    sources = list(set([doc.metadata.get('source', 'Unknown') for doc in result.get("source_documents", [])]))
    return {answer}

# --- 4. 라우터가 사용할 최종 도구 맵 ---
tool_map = {
    "sql": sql_expert_tool,
    "attack": attack_search_tool,
    "traffic": traffic_search_tool,
    "log": log_search_tool,
    "security_knowledge": security_knowledge_tool,
}