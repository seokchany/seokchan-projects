# src/services/langchain_agent/tools.py

import json
import traceback
import re
from langchain.tools import tool, Tool
from langchain_community.tools import TavilySearchResults
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from elasticsearch import Elasticsearch

from ...core.database import engine
from ...core.config import settings

# --- 1. 공통 LLM 및 클라이언트 초기화 ---

# 모든 도구와 에이전트가 공유할 단일 LLM 인스턴스
llm = ChatGoogleGenerativeAI(
    model="models/gemini-1.5-flash",
    google_api_key=settings.google_api_key,
    temperature=0
)

es_client = Elasticsearch(
    f"{settings.elasticsearch_host}:{settings.elasticsearch_port}",
    request_timeout=settings.elasticsearch_request_timeout
)


# --- 2. JSON 추출 헬퍼 함수 ---
def extract_json_from_string(text: str) -> str:
    """LLM이 반환한 텍스트에서 JSON 코드 블록만 안정적으로 추출합니다."""
    match = re.search(r"```(json)?\n(.*?)```", text, re.S)
    if match:
        return match.group(2).strip()
    try:
        start = text.index("{")
        end = text.rindex("}") + 1
        return text[start:end]
    except ValueError:
        return ""

# --- 3. 전문가 도구(Tool) 정의 ---

# --- [도구 1: SQL 전문가] ---
db = SQLDatabase(engine=engine)
sql_agent_executor = create_sql_agent(llm=llm, db=db, agent_type="openai-tools", verbose=True, handle_parsing_errors=True)
sql_tool = Tool(
    name="sql_database_expert",
    func=sql_agent_executor.invoke,
    description="PostgreSQL DB 관련 질문(사용자 정보, 인시던트 이력 등)에 사용하는 전문가입니다."
)

# --- [도구 2: Elasticsearch 전문가] ---
@tool
def elasticsearch_expert(question_with_context: str) -> str:
    """공격, 네트워크 트래픽, 시스템 로그 데이터에 대한 질문에 사용하는 전문가입니다. 질문과 함께 '[User ID: user_id]' 형식의 컨텍스트를 입력받아야 합니다."""
    try:
        match = re.search(r"\[User ID: ([\w\-]+)\]", question_with_context)
        if not match:
            return "Error: User ID context is missing from the input."
        user_id = match.group(1)
        question = question_with_context.replace(match.group(0), "").strip()
        print(f"--- [디버그] 파싱된 User ID: {user_id} ---")
        print(f"--- [디버그] 파싱된 Question: {question} ---")
    except Exception as e:
        return f"Error parsing input: {e}"

    schema_info = """
    'winlogbeat_data' (System Logs) fields: ["@timestamp", "user_id", "host.name", "log.level", "event.action", "message"]
    'packetbeat_data' (Network Traffic) available fields: 
    ["@timestamp", "user_id", "Src_IP", "Dst_Port", "Protocol", "Flow_Duration", "Tot_Fwd_Pkts", "Flow_Byts_per_s", "SYN_Flag_Cnt", "RST_Flag_Cnt"]
    
    'attack_detections' (Attack Data) fields: ["@timestamp", "user_id", "rule.name", "rule.severity", "source.ip", "message"]
    """

    query_gen_template = """
You are a world-class Elasticsearch query expert. Your task is to generate a valid Elasticsearch DSL query.

**Index Schema (Use ONLY these fields):**
{schema}

**CRUCIAL INSTRUCTIONS (You MUST follow these rules):**
1.  Filter by user ID ('{user_id}') using a `match` query on the `user_id` field.
2.  For aggregations (`aggs`) or sorting (`sort`) on text-like fields, you MUST append `.keyword` to the field name.
3.  Choose ONLY ONE relevant index based on the question.
4.  The query body MUST NOT contain an "index" key.
5.  To prevent excessive data, the "size" parameter should be small, like 10, unless the user asks for more.
6.  Only output the raw JSON of the DSL query, inside a ```json ... ``` code block.

User Question: {question}
DSL Query:
"""

    query_gen_prompt = PromptTemplate.from_template(query_gen_template)
    query_chain = query_gen_prompt | llm | StrOutputParser()
    llm_output_str = query_chain.invoke({"user_id": user_id, "question": question, "schema": schema_info})
    
    dsl_query_str = extract_json_from_string(llm_output_str)
    print(f"--- [디버그] 추출된 DSL 쿼리 ---\n{dsl_query_str}")

    if not dsl_query_str:
        return f"LLM이 유효한 DSL 쿼리를 생성하지 못했습니다. LLM 원본 응답: {llm_output_str}"

    try:
        query_dict = json.loads(dsl_query_str)
        
        # ▼▼▼ [핵심 수정] 여러 인덱스를 동시에 검색하도록 로직을 변경합니다. ▼▼▼
        
        # 검색할 인덱스들을 담을 리스트
        indices_to_search = []
        question_lower = question.lower() # 질문을 소문자로 변환

        # 질문에 키워드가 포함되어 있으면 해당 인덱스를 리스트에 추가
        if any(word in question_lower for word in ["공격", "attack", "침입"]):
            indices_to_search.append("attack_detections")
        if any(word in question_lower for word in ["트래픽", "traffic", "패킷", "packet"]):
            indices_to_search.append("packetbeat_data")
        if any(word in question_lower for word in ["로그", "log", "이벤트", "event"]):
            indices_to_search.append("winlogbeat_data")

        # 만약 아무 인덱스도 선택되지 않았다면, 모든 인덱스를 검색 대상으로 함
        if not indices_to_search:
            indices_to_search = ["attack_detections", "packetbeat_data", "winlogbeat_data"]

        # 리스트를 콤마로 연결된 문자열로 변환 (예: "winlogbeat-raw,packetbeat-raw")
        index_name = ",".join(indices_to_search)

        print(f"--- [디버그] 선택된 인덱스: {index_name} ---")
        es_result = es_client.search(index=index_name, body=query_dict)
        aggregations = es_result.get('aggregations')
        hits = es_result.get('hits', {}).get('hits', [])
        if not aggregations and not hits:
            return "요청하신 조건에 맞는 데이터를 찾을 수 없습니다."
    except Exception as e:
        # ... (에러 처리 로Dtlr) ...
        return f"쿼리 실행 실패: {e}. 생성된 쿼리: {dsl_query_str}"

    print("--- [디버그] 데이터 검색 성공 ---")

    # ▼▼▼ [수정 2] LLM에게 전달하기 전에 데이터를 정제하고 요약합니다. ▼▼▼
    
    # 집계 결과가 있으면, 그 결과를 반환
    if aggregations:
        result_to_return = aggregations
    else:
        # 검색 결과(hits)가 너무 많으면 상위 5개만 사용하고, 필요한 필드만 추출
        limited_hits = hits[:5] # 최대 5개의 결과만 사용
        result_to_return = [
            {
                "timestamp": hit['_source'].get('@timestamp'),
                "message": hit['_source'].get('message'),
                "log.level": hit['_source'].get('log.level'),
                "host.name": hit['_source'].get('host.name')
            }
            for hit in limited_hits
        ]

    # 최종 요약은 마스터 에이전트가 하도록 정제된 데이터를 반환합니다.
    return json.dumps(result_to_return, ensure_ascii=False)

# --- [도구 3: 웹 검색 전문가] ---
web_search_tool = Tool(
    name="web_search_expert",
    func=TavilySearchResults(max_results=3).invoke,
    description="최신 정보, 외부 문서, 새로운 공격 대응법을 찾을 때 사용하는 웹 검색 전문가입니다."
)

# --- 4. 최종 도구 리스트 ---
master_tools = [sql_tool, elasticsearch_expert, web_search_tool]